"""
mock_sybilion.py — stands in for the real Sybilion API tonight.

It returns the SHAPE the brief documents: a probabilistic month-by-month
forecast (bands), driver importance scored per horizon, and backtest accuracy.
On Friday you replace this one file with a real client that calls the API and
returns the same shape. Nothing else in the repo needs to change.

CONFIRM the real field names from sybilion.dev/docs on Friday and adjust here.
"""
import random


def get_forecast(series, keywords, horizon_months=6, seed=42):
    """
    series:   list of monthly numbers (your real time series Friday)
    keywords: list of strings (the contextual keywords — quality matters)
    returns:  dict with 'months', 'bands', 'drivers', 'backtest'
    """
    rng = random.Random(seed)
    last = series[-1] if series else 100.0

    # --- probabilistic forecast: p10/p50/p90 per future month ---
    bands = []
    p50 = last
    for m in range(1, horizon_months + 1):
        drift = rng.uniform(-0.025, 0.008)       # mild downward bias: base case = WAIT
        p50 = p50 * (1 + drift)
        spread = p50 * (0.015 + 0.006 * m)       # uncertainty widens with horizon
        bands.append({"month": m,
                      "p10": round(p50 - spread, 2),
                      "p50": round(p50, 2),
                      "p90": round(p50 + spread, 2)})

    # --- drivers, scored by importance at each horizon ---
    pool = keywords or ["demand", "supply", "fx", "inventory"]
    drivers = []
    for h in (1, 3, 6):
        if h <= horizon_months:
            ranked = sorted(pool, key=lambda k: rng.random())
            drivers.append({"horizon_months": h,
                            "scores": [{"name": ranked[i],
                                        "importance": round(0.5 - 0.12 * i + rng.uniform(-0.05, 0.05), 2)}
                                       for i in range(min(3, len(ranked)))]})

    # --- backtest accuracy summary (the API provides this) ---
    backtest = {"mae_pct": round(rng.uniform(3, 7), 2),
                "directional_accuracy": round(rng.uniform(0.6, 0.78), 2),
                "n_periods": 36}

    return {"current_price": round(last, 2),
            "horizon_months": horizon_months,
            "bands": bands,
            "drivers": drivers,
            "backtest": backtest}
