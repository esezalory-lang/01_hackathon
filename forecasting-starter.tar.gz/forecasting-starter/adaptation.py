"""
adaptation.py — the Sunday-winning capability.

A judge changes an assumption mid-run. Because decide() is a pure function,
adapting is just: mutate the forecast inputs -> re-run -> diff the decisions ->
narrate what flipped and why. Rehearse 2-3 specific shocks before the demo.
"""
import copy
from decision_engine import decide


def apply_shock(forecast, shock):
    """
    Return a NEW forecast with the shock applied (original untouched — purity).
    shock examples:
      {"type": "driver_importance", "name": "supply", "to": 0.6}
      {"type": "band_shift", "pct": 8}     # whole forecast shifts up 8% (e.g., supply shock)
    """
    f = copy.deepcopy(forecast)
    if shock["type"] == "band_shift":
        factor = 1 + shock["pct"] / 100
        for b in f["bands"]:
            for k in ("p10", "p50", "p90"):
                b[k] = round(b[k] * factor, 2)
    elif shock["type"] == "driver_importance":
        for d in f["drivers"]:
            for s in d["scores"]:
                if s["name"] == shock["name"]:
                    s["importance"] = shock["to"]
    return f


def diff_decisions(before, after):
    """Structured delta between two decision objects, for the narrator."""
    changed = {}
    for key in ("action", "confidence", "expected_saving_pct",
                "downside_risk_pct", "band_width_pct"):
        if before.get(key) != after.get(key):
            changed[key] = {"from": before.get(key), "to": after.get(key)}
    return {"flipped": before["action"] != after["action"], "changes": changed}


if __name__ == "__main__":
    # quick self-test on the mock
    from mock_sybilion import get_forecast
    fc = get_forecast([100, 101, 102, 103, 104, 105], ["demand", "supply", "fx"], horizon_months=6)
    base = decide(fc)
    shocked = decide(apply_shock(fc, {"type": "band_shift", "pct": 9}))
    print("BEFORE:", base["action"], base["downside_risk_pct"])
    print("AFTER :", shocked["action"], shocked["downside_risk_pct"])
    print("DELTA :", diff_decisions(base, shocked))
