"""
backtest.py — grounds your recommendations in evidence (the brief rewards this).

Replays your decision policy over historical data and compares it to a naive
baseline (always BUY_NOW). Produces a number you can put on a slide:
"our policy would have saved X% vs always buying immediately."

Tonight this runs on a synthetic history. Friday, feed it the real series +
the API's backtest data and report the real figure.
"""
from mock_sybilion import get_forecast
from decision_engine import decide


def run_backtest(history, keywords, decision_horizon=3, step=3):
    """
    history: a long monthly series. We walk through it, and at each point ask the
    engine what to do, then check what actually happened `decision_horizon` later.
    """
    naive_cost = 0.0
    policy_cost = 0.0
    decisions = []
    for t in range(12, len(history) - decision_horizon, step):
        window = history[:t]
        actual_future = history[t + decision_horizon - 1]
        fc = get_forecast(window, keywords, horizon_months=decision_horizon, seed=t)
        d = decide(fc, decision_horizon=decision_horizon)
        buy_now_price = history[t - 1]

        naive_cost += buy_now_price                      # baseline always buys now
        if d["action"] == "BUY_NOW":
            policy_cost += buy_now_price
        elif d["action"] == "WAIT":
            policy_cost += actual_future                 # we waited; paid the later price
        else:  # SPLIT: half now, half later
            policy_cost += 0.5 * buy_now_price + 0.5 * actual_future
        decisions.append(d["action"])

    saving_pct = round((naive_cost - policy_cost) / naive_cost * 100, 2)
    return {"policy_saving_pct_vs_naive": saving_pct,
            "n_decisions": len(decisions),
            "action_counts": {a: decisions.count(a) for a in set(decisions)}}


if __name__ == "__main__":
    # synthetic 60-month history with a gentle cycle, for tonight
    import math
    hist = [100 + 10 * math.sin(i / 6) + i * 0.2 for i in range(60)]
    print(run_backtest(hist, ["China demand", "mine supply", "USD index"]))
