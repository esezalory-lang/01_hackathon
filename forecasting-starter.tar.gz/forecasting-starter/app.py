"""
app.py — the dashboard (visible reasoning + the live demo surface).
Run locally:  streamlit run app.py

Three panels: forecast bands, driver importance, and a decision card with
live "shock" buttons that demonstrate adaptive behaviour on stage.
"""
import streamlit as st
from mock_sybilion import get_forecast          # Friday: swap for real client
from decision_engine import decide
from adaptation import apply_shock, diff_decisions
from explain import explain

st.set_page_config(page_title="Decision Agent", layout="wide")
st.title("Procurement Decision Agent")
st.caption("The engine decides. The model only narrates. Demo runs on the MOCK API.")

# --- inputs ---
keywords = st.text_input("Keywords (comma-separated)",
                         "China demand, mine supply, USD index").split(",")
horizon = st.slider("Decision horizon (months)", 1, 6, 3)
series = [100, 101, 102, 103, 104, 105]          # Friday: your real time series

forecast = get_forecast(series, [k.strip() for k in keywords], horizon_months=6)
base = decide(forecast, decision_horizon=horizon)

# --- live shock (adaptive behaviour) ---
st.sidebar.header("Live assumption change")
shock = None
if st.sidebar.button("Supply shock (+8% bands)"):
    shock = {"type": "band_shift", "pct": 8}
if st.sidebar.button("Demand collapse (-8% bands)"):
    shock = {"type": "band_shift", "pct": -8}

current = base
delta = None
if shock:
    shocked_fc = apply_shock(forecast, shock)
    current = decide(shocked_fc, decision_horizon=horizon)
    delta = diff_decisions(base, current)
    forecast = shocked_fc

col1, col2 = st.columns(2)

with col1:
    st.subheader("Forecast (bands)")
    chart = {f"month {b['month']}": b["p50"] for b in forecast["bands"]}
    st.line_chart(chart)
    st.caption("p50 shown; p10/p90 in the table below")
    st.dataframe(forecast["bands"])

with col2:
    st.subheader("Driver importance")
    for d in forecast["drivers"]:
        st.write(f"**{d['horizon_months']}-month horizon**")
        st.bar_chart({s["name"]: s["importance"] for s in d["scores"]})

st.subheader("Decision")
c = current
color = {"BUY_NOW": "🔴", "WAIT": "🟢", "SPLIT": "🟡"}[c["action"]]
st.metric("Recommendation", f"{color} {c['action']}", f"confidence {c['confidence']}")
m1, m2, m3 = st.columns(3)
m1.metric("Expected saving from waiting", f"{c['expected_saving_pct']}%")
m2.metric("Upside price risk", f"{c['downside_risk_pct']}%")
m3.metric("Uncertainty (band width)", f"{c['band_width_pct']}%")

if delta and delta["flipped"]:
    st.warning(f"Assumption changed — recommendation flipped {base['action']} → {c['action']}")

st.info(explain(c, delta))
