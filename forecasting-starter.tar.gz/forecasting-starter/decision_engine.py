"""
decision_engine.py — YOUR CORE IP.

A PURE FUNCTION: same forecast in -> same decision out, no hidden state.
That purity is what makes the live "change an assumption -> recommendation
updates" demo trivial. The engine DECIDES. The LLM only narrates (see explain.py).

Worked example: commodity procurement timing. Action = BUY_NOW / WAIT / SPLIT.
Swap the policy for your domain, but keep the structure: read bands -> compute
expected value + downside risk + uncertainty -> apply explicit rules -> emit a
structured decision object where every number is shown and explained.
"""

# --- TUNING KNOBS (expose these; being able to state them = substantive logic) ---
UNCERTAINTY_THRESHOLD = 12.0   # band width % above which we refuse to fully commit
DOWNSIDE_THRESHOLD = 6.0       # % price rise risk that triggers locking in now
SAVING_THRESHOLD = 3.0         # % expected saving from waiting that justifies WAIT


def decide(forecast, decision_horizon=None):
    """forecast: the dict from the Sybilion client (or mock). Returns a decision dict."""
    bands = forecast["bands"]
    h = decision_horizon or forecast["horizon_months"]
    target = bands[min(h, len(bands)) - 1]          # band at the decision horizon
    current = forecast["current_price"]

    # 1. expected future price (probability-weighted; p50 is the median proxy)
    expected = target["p50"]
    # 2. downside risk: how much price could RISE against us (upper band)
    downside_risk_pct = round((target["p90"] - current) / current * 100, 2)
    # 3. expected saving from waiting (positive = price expected to fall)
    expected_saving_pct = round((current - expected) / current * 100, 2)
    # 4. uncertainty: band width relative to median
    band_width_pct = round((target["p90"] - target["p10"]) / target["p50"] * 100, 2)

    # 5. top driver at the decision horizon (multi-signal synthesis hook)
    top_driver = _top_driver(forecast["drivers"], h)

    # 6. POLICY -> action (explicit, ordered, traceable)
    rationale = []
    if band_width_pct > UNCERTAINTY_THRESHOLD:
        action = "SPLIT"
        rationale.append(f"uncertainty high (band width {band_width_pct}% > {UNCERTAINTY_THRESHOLD}%)")
    elif downside_risk_pct > DOWNSIDE_THRESHOLD:
        action = "BUY_NOW"
        rationale.append(f"upside price risk {downside_risk_pct}% > {DOWNSIDE_THRESHOLD}%")
    elif expected_saving_pct > SAVING_THRESHOLD:
        action = "WAIT"
        rationale.append(f"expected saving {expected_saving_pct}% > {SAVING_THRESHOLD}%")
    else:
        action = "BUY_NOW"
        rationale.append("no clear edge to waiting; lock in")

    # confidence: narrower bands -> higher confidence (simple, defensible mapping)
    confidence = round(max(0.4, min(0.95, 1 - band_width_pct / 30)), 2)

    return {
        "action": action,
        "confidence": confidence,
        "expected_saving_pct": expected_saving_pct,
        "downside_risk_pct": downside_risk_pct,
        "band_width_pct": band_width_pct,
        "decision_horizon_months": h,
        "top_driver": top_driver,
        "rationale": rationale,
        "backtest_directional_accuracy": forecast["backtest"]["directional_accuracy"],
    }


def _top_driver(drivers, horizon):
    """Pick the highest-importance driver at the closest available horizon."""
    best = min(drivers, key=lambda d: abs(d["horizon_months"] - horizon)) if drivers else None
    if not best or not best["scores"]:
        return None
    top = max(best["scores"], key=lambda s: s["importance"])
    return {"name": top["name"], "importance": top["importance"], "horizon_months": best["horizon_months"]}
